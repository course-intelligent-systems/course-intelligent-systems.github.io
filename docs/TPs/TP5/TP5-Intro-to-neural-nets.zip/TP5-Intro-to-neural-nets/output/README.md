This is the output directory for trained models, 
plots and trained/validation/test data sets.
